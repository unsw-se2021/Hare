Feature: name of feature, e.g. "Scan ingredients"
As a(n) actor:

So that I can do something

I want to perform some action, to achieve this

Scenario: name of feature with a bit of elaboration

GIVEN: I am on the main page
WHEN: I click "scan ingredients"
THEN: I should be on the camera page
WHEN: I click "take picture"
AND: Confirm it is the picture I want to use
THEN: I should be on a page with information about the ingredients in the picture
