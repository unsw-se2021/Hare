# US-2 

**Feature:** Quick Scan of packaging with Uploaded image\
**As a** guest  
 
**So that** I can find information about ingredients in a product

**I want to** upload a picture of the ingredients on a product
<hr>

**Scenario:** Upload a picture of an ingredients list to receive 
information about each ingredient\

**GIVEN:** I am on the default landing page\
**AND:** I have not logged in\
**WHEN:** I click the upload icon\
**THEN:** I should be on a file selection window/page\
**WHEN:** I select an image\
**AND:** I click sumbit\
**THEN:** I see a page with details about the ingredients in the picture  
  

